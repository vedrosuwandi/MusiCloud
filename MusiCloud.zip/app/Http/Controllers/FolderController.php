<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\DB;
use App\Models\Folder;
use App\Models\Music;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class FolderController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $folders = Folder::where('user_ID', Auth::user()->id)->get();

        return view('MusiCloud.folder', compact('folders'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $folder = new Folder();
        $folder->folder_Name = $request->folder_Name;
        $folder->user_ID = Auth::user()->id;
        $folder->save();
        return redirect()->back();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {

        $folder = Folder::where('folder_ID' , $id)->first();
        $musics = Music::where('folder_ID', $id)->get();

        return view('MusiCloud.music', compact('folder', 'musics'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {

        $folder = Folder::where('folder_ID' , $id)->first();
        Storage::disk('s3')->deleteDirectory($folder->folder_Name);
        DB::table('folders')->where('folder_ID' , $id)->delete();
        return redirect()->back();
    }
}
