<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap JS -->
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>


    <!-- Bootstrap CSS -->

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
    <link rel="icon" type="image" href="/img/icon.jpg">
    <title>MusiCloud</title>
    </head>
    <style>
        .navbar-text{
            margin-right: 20px;
        }
    </style>

    <?php if(session('add')): ?>
    <div class="alert alert-success">
        <?php echo e(session('add')); ?>

    </div>
    <?php endif; ?>

    <body>
        <!-- Option 1: Bootstrap Bundle with Popper -->
        <nav class="navbar navbar-expand-lg navbar-light bg-light">
            <div class="container-fluid">
            <a class="navbar-brand" href="/home">Home</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarText" aria-controls="navbarText" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarText">
                <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item">
                    <a class="nav-link" type="button" data-toggle="modal" data-target="#NewFolder">New Folder</a>
                </li>
                </ul>
                <span class="navbar-text">
                    <?php echo e(Auth::user()->name); ?>

                </span>
            </div>
            </div>
        </nav>

        <!-- Create Folder -->
        <div class="modal fade" id="NewFolder" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Create Folder</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
                </div>
                <form action="<?php echo e(route('folder.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="modal-body">
                        <div class="form-group">
                            <label for="exampleFormControlInput1" >Folder Name</label>
                            <input type="label" class="form-control" id="exampleFormControlInput1" placeholder="Folder Name" name="folder_Name">
                        </div>
                    </div>
                    <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Create Folder</button>
                    </div>
                </form>
            </div>
            </div>
        </div>

        <div class="container">
            <div class = "row mt-5">
                <div class = "col-12">
                    <div class="col-sm-12">
                    <table class="table table-borderless">
                        <thead>
                            <tr style="background-color: #A28BE7; color: white">
                                <th scope="col">Folder</th>
                                <th scope="col">Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $folders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $folder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="col-sm-9">
                                    <a href="<?php echo e(route('folder.show' , $folder->folder_ID)); ?>"  id='foldername' class="list-group-item list-group-item-action"><?php echo e($folder->folder_Name); ?></a>
                                </td>
                                <td  class="col-sm-1">
                                    <form action="<?php echo e(route('folder.destroy' , array('id' => $folder->folder_ID))); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <?php echo e(method_field('DELETE')); ?>

                                        <button type="submit" class="btn btn-outline-danger ml-1">Delete</button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    </div>
                </div>
            </div>
        </div>

  </body>

</html>
<?php /**PATH D:\Course\Projects\Web\CloudFP\resources\views/MusiCloud/folder.blade.php ENDPATH**/ ?>